import str from './util.js';

console.log(str);
